USE RestaurantOrderingSystem;

INSERT INTO CUSTOMERS (Customer_ID, Customer_Name, Customer_Phone, Customer_Mail)
VALUES 
    ('CUST001', 'Alice Johnson', '123-456-7890', 'alice.johnson@example.com'),
    ('CUST002', 'Bob Smith', '234-567-8901', 'bob.smith@example.com'),
    ('CUST003', 'Charlie Brown', '345-678-9012', 'charlie.brown@example.com'),
    ('CUST004', 'David Clark', '456-789-0123', 'david.clark@example.com'),
    ('CUST005', 'Eva Green', '567-890-1234', 'eva.green@example.com'),
    ('CUST006', 'Frank White', '678-901-2345', 'frank.white@example.com'),
    ('CUST007', 'Grace Lee', '789-012-3456', 'grace.lee@example.com'),
    ('CUST008', 'Henry Adams', '890-123-4567', 'henry.adams@example.com'),
    ('CUST009', 'Ivy Wilson', '901-234-5678', 'ivy.wilson@example.com'),
    ('CUST010', 'Jack Turner', '012-345-6789', 'jack.turner@example.com'),
    ('CUST011', 'Kara Scott', '123-456-7891', 'kara.scott@example.com'),
    ('CUST012', 'Liam Miller', '234-567-8902', 'liam.miller@example.com'),
    ('CUST013', 'Mia Taylor', '345-678-9013', 'mia.taylor@example.com'),
    ('CUST014', 'Noah Brown', '456-789-0124', 'noah.brown@example.com'),
    ('CUST015', 'Olivia Moore', '567-890-1235', 'olivia.moore@example.com'),
    ('CUST016', 'Paul Martin', '678-901-2346', 'paul.martin@example.com'),
    ('CUST017', 'Quinn Davis', '789-012-3457', 'quinn.davis@example.com'),
    ('CUST018', 'Ruby Evans', '890-123-4568', 'ruby.evans@example.com'),
    ('CUST019', 'Sam Harris', '901-234-5679', 'sam.harris@example.com'),
    ('CUST020', 'Tina Bell', '012-345-6790', 'tina.bell@example.com');

INSERT INTO RESTAURANT_TABLES (Table_ID, Table_Size, Table_Status)
VALUES 
    (1, 2, TRUE),
    (2, 4, FALSE),
    (3, 6, TRUE),
    (4, 4, TRUE),
    (5, 8, FALSE);

INSERT INTO MENUS (Item_ID, Item_Name, Description, Price, Availability, Time_Created)
VALUES 
    ('ITEM1', 'Margherita Pizza', 'Classic margherita pizza with tomato, mozzarella, and basil', 12.99, TRUE, '2024-01-15 12:00:00'),
    ('ITEM2', 'Cheeseburger', 'Juicy cheeseburger with lettuce, tomato, and cheese', 10.49, TRUE, '2024-02-20 15:30:00'),
    ('ITEM3', 'Caesar Salad', 'Fresh romaine lettuce, Caesar dressing, croutons, and parmesan', 8.99, TRUE, '2024-03-10 11:15:00'),
    ('ITEM4', 'Grilled Salmon', 'Grilled salmon with lemon butter sauce', 15.99, TRUE, '2024-03-22 18:45:00'),
    ('ITEM5', 'Spaghetti Carbonara', 'Pasta with creamy carbonara sauce, bacon, and parmesan', 11.99, FALSE, '2024-04-01 14:00:00');

INSERT INTO `ORDERS` (Order_ID, Customer_ID, Item_ID, Table_ID, Quantity, TimeCreated, Prepared)
VALUES 
    ('ORD001', 'CUST001', 'ITEM1', 1, 1, '2024-10-01 12:30:00', TRUE),
    ('ORD002', 'CUST002', 'ITEM2', 2, 2, '2024-10-02 14:00:00', FALSE),
    ('ORD003', 'CUST003', 'ITEM3', 3, 1, '2024-10-03 09:15:00', FALSE),
    ('ORD004', 'CUST004', 'ITEM4', 4, 3, '2024-10-04 18:45:00', FALSE),
    ('ORD005', 'CUST005', 'ITEM5', 5, 1, '2024-10-05 11:00:00', FALSE),
    ('ORD006', 'CUST001', 'ITEM1', 1, 2, '2024-10-06 15:30:00', FALSE),
    ('ORD007', 'CUST002', 'ITEM2', 2, 1, '2024-10-07 08:00:00', FALSE),
    ('ORD008', 'CUST003', 'ITEM3', 3, 1, '2024-10-08 10:30:00', FALSE),
    ('ORD009', 'CUST004', 'ITEM4', 4, 2, '2024-10-09 13:15:00', FALSE),
    ('ORD010', 'CUST005', 'ITEM5', 5, 1, '2024-10-10 16:00:00', FALSE),
    ('ORD011', 'CUST001', 'ITEM2', 1, 3, '2024-10-11 11:45:00', false),
('ORD012', 'CUST002', 'ITEM3', 2, 2, '2024-10-12 14:30:00', false),
('ORD013', 'CUST003', 'ITEM4', 3, 1, '2024-10-13 09:00:00', false),
('ORD014', 'CUST004', 'ITEM5', 4, 2, '2024-10-14 17:15:00', false),
('ORD015', 'CUST005', 'ITEM1', 5, 1, '2024-10-15 12:00:00', false),
('ORD016', 'CUST001', 'ITEM3', 1, 2, '2024-10-16 18:30:00', false),
('ORD017', 'CUST002', 'ITEM4', 2, 3, '2024-10-17 08:45:00', false),
('ORD018', 'CUST003', 'ITEM5', 3, 2, '2024-10-18 10:15:00', false),
('ORD019', 'CUST004', 'ITEM1', 4, 4, '2024-10-19 13:45:00', false),
('ORD020', 'CUST005', 'ITEM2', 5, 1, '2024-10-20 09:30:00', false),
('ORD021', 'CUST001', 'ITEM4', 1, 1, '2024-10-21 15:00:00', false),
('ORD022', 'CUST002', 'ITEM5', 2, 2, '2024-10-22 16:30:00', false),
('ORD023', 'CUST003', 'ITEM1', 3, 3, '2024-10-23 11:00:00', false),
('ORD024', 'CUST004', 'ITEM2', 4, 1, '2024-10-24 08:30:00', false),
('ORD025', 'CUST005', 'ITEM3', 5, 2, '2024-10-25 14:45:00', false),
('ORD026', 'CUST001', 'ITEM5', 1, 3, '2024-10-26 10:00:00', false),
('ORD027', 'CUST002', 'ITEM1', 2, 1, '2024-10-27 18:15:00', false),
('ORD028', 'CUST003', 'ITEM2', 3, 4, '2024-10-28 09:15:00', false),
('ORD029', 'CUST004', 'ITEM3', 4, 2, '2024-10-29 17:30:00', false),
('ORD030', 'CUST005', 'ITEM4', 5, 1, '2024-10-30 14:00:00', false),
('ORD031', 'CUST001', 'ITEM2', 1, 3, '2024-10-31 12:15:00', false),
('ORD032', 'CUST002', 'ITEM3', 2, 1, '2024-11-01 15:45:00', false),
('ORD033', 'CUST003', 'ITEM4', 3, 2, '2024-11-02 08:45:00', false),
('ORD034', 'CUST004', 'ITEM5', 4, 3, '2024-11-03 13:00:00', false),
('ORD035', 'CUST005', 'ITEM1', 5, 1, '2024-11-04 09:30:00', false),
('ORD036', 'CUST001', 'ITEM3', 1, 1, '2024-11-05 18:00:00', false),
('ORD037', 'CUST002', 'ITEM4', 2, 2, '2024-11-06 11:15:00', false),
('ORD038', 'CUST003', 'ITEM5', 3, 1, '2024-11-07 16:45:00', false),
('ORD039', 'CUST004', 'ITEM1', 4, 2, '2024-11-08 13:30:00', false),
('ORD040', 'CUST005', 'ITEM2', 5, 1, '2024-11-09 08:15:00', false);

INSERT INTO PAYMENTS (Payment_ID, Customer_ID, Total_Amount, Payment_Status, TimeStamp)
VALUES 
    ('PAY001', 'CUST001', 12.99, TRUE, '2024-10-05 12:30:00'),
    ('PAY002', 'CUST002', 20.98, FALSE, '2024-10-05 13:00:00'),
    ('PAY003', 'CUST003', 8.99, TRUE, '2024-10-05 13:15:00'),
    ('PAY004', 'CUST004', 47.97, TRUE, '2024-10-05 13:45:00'),
    ('PAY005', 'CUST005', 11.99, FALSE, '2024-10-05 14:00:00'),
    ('PAY006', 'CUST006', 15.50, FALSE, '2024-10-05 14:30:00'),
    ('PAY007', 'CUST007', 9.75, TRUE, '2024-10-05 15:00:00'),
    ('PAY008', 'CUST008', 29.99, FALSE, '2024-10-05 15:30:00'),
    ('PAY009', 'CUST009', 17.49, TRUE, '2024-10-05 16:00:00'),
    ('PAY010', 'CUST010', 42.00, FALSE, '2024-10-05 16:30:00'),
    ('PAY011', 'CUST011', 23.50, TRUE, '2024-10-05 17:00:00'),
    ('PAY012', 'CUST012', 50.75, FALSE, '2024-10-05 17:30:00'),
    ('PAY013', 'CUST013', 18.25, TRUE, '2024-10-05 18:00:00'),
    ('PAY014', 'CUST014', 32.99, TRUE, '2024-10-05 18:30:00'),
    ('PAY015', 'CUST015', 14.00, FALSE, '2024-10-05 19:00:00'),
    ('PAY016', 'CUST016', 25.99, TRUE, '2024-10-05 19:30:00'),
    ('PAY017', 'CUST017', 37.45, FALSE, '2024-10-05 20:00:00'),
    ('PAY018', 'CUST018', 19.99, TRUE, '2024-10-05 20:30:00'),
    ('PAY019', 'CUST019', 22.50, FALSE, '2024-10-05 21:00:00'),
    ('PAY020', 'CUST020', 45.00, TRUE, '2024-10-05 21:30:00');

INSERT INTO CARTS (Cart_ID, Customer_ID, Item_ID, Quantity, Time_Added)
VALUES 
    ('CART001', 'CUST001', 'ITEM1', 2, '2024-11-05 12:45:00'),
    ('CART001', 'CUST001', 'ITEM3', 1, '2024-11-05 15:30:00'), 

    ('CART002', 'CUST002', 'ITEM3', 1, '2024-11-05 13:15:00'),
    ('CART002', 'CUST002', 'ITEM4', 1, '2024-11-05 16:00:00'), 

    ('CART003', 'CUST003', 'ITEM2', 3, '2024-11-05 14:00:00'),
    ('CART003', 'CUST003', 'ITEM5', 1, '2024-11-05 16:30:00'), 

    ('CART004', 'CUST004', 'ITEM4', 1, '2024-11-05 14:30:00'),
    ('CART004', 'CUST004', 'ITEM1', 2, '2024-11-05 17:00:00'), 

    ('CART005', 'CUST005', 'ITEM5', 2, '2024-11-05 15:00:00'),
    ('CART005', 'CUST005', 'ITEM2', 1, '2024-11-05 17:30:00'); 

SELECT * FROM CUSTOMERS;
SELECT * FROM RESTAURANT_TABLES;
SELECT * FROM MENUS;
SELECT * FROM `ORDERS`;
SELECT * FROM PAYMENTS;
select * from carts;
