use RestaurantOrderingSystem;
drop table if exists carts;
drop table PAYMENTS;
drop table `ORDERS`;
drop table MENUS;
drop table CUSTOMERS;
drop table RESTAURANT_TABLES;

drop database restaurantorderingsystem;

