show databases;
create database RestaurantOrderingSystem;
use RestaurantOrderingSystem;
CREATE TABLE CUSTOMERS (
    Customer_ID VARCHAR(36) PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Customer_Phone VARCHAR(15) NOT NULL,
    Customer_Mail VARCHAR(255)
);

CREATE TABLE RESTAURANT_TABLES (
    Table_ID INT PRIMARY KEY AUTO_INCREMENT,
    Table_Size SMALLINT,
    Table_Status BOOLEAN
);

CREATE TABLE MENUS (
    Item_ID VARCHAR(36) PRIMARY KEY,
    Item_Name VARCHAR(100) NOT NULL UNIQUE,
    Description TEXT,
    Price DECIMAL(10, 2) NOT NULL,
    Availability BOOLEAN,
    Time_Created datetime
);

CREATE TABLE `ORDERS` (
    Order_ID VARCHAR(36) PRIMARY KEY,
    Customer_ID VARCHAR(36),
    Item_ID VARCHAR(36),
    Table_ID INT,
    Quantity INT CHECK (Quantity > 0),
    TimeCreated datetime,
    Prepared BOOLEAN,
    FOREIGN KEY (Customer_ID) REFERENCES CUSTOMERS(Customer_ID),
    FOREIGN KEY (Item_ID) REFERENCES MENUS(Item_ID),
    FOREIGN KEY (Table_ID) REFERENCES RESTAURANT_TABLES(Table_ID)
);

CREATE TABLE PAYMENTS (
    Payment_ID VARCHAR(36) PRIMARY KEY,
    Customer_ID VARCHAR(36),
    Total_Amount DECIMAL(10, 2) NOT NULL,
    Payment_Status BOOLEAN,
    TimeStamp DATETIME,
    FOREIGN KEY (Customer_ID) REFERENCES CUSTOMERS(Customer_ID)
);

CREATE TABLE CARTS (
    Cart_ID VARCHAR(36),
    Customer_ID VARCHAR(36),
    Item_ID VARCHAR(36),
    Quantity INT CHECK (Quantity > 0),
    Time_Added DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Customer_ID) REFERENCES CUSTOMERS(Customer_ID),
    FOREIGN KEY (Item_ID) REFERENCES MENUS(Item_ID)
);


show tables;
SELECT VERSION();
